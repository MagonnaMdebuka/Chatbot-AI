import 'package:flutter/material.dart';
import 'package:flutter_chatbot_app/screens/model.dart';
import 'package:google_generative_ai/google_generative_ai.dart';
import 'package:intl/intl.dart';

class ChatBot extends StatefulWidget {
  const ChatBot({super.key});
  @override
  _ChatBotState createState() => _ChatBotState();
}

class _ChatBotState extends State<ChatBot> {
  TextEditingController messageController = TextEditingController();
  static const apiKey = "AIzaSyA8UXM-wGPftHZeZC04Yk1MpTuPZrf7gZQ";
  final model = GenerativeModel(model: "gemini-pro", apiKey: apiKey);
  final List<ModelMessage> prompt = [];
  bool isTyping = false;

  Future<void> sendMessage() async {
    final message = messageController.text;

    // Display user's message on the right
    setState(() {
      messageController.clear();
      prompt.add(ModelMessage(
          isPrompt: true, message: message, time: DateTime.now()));
    });

    // Show typing indicator
    setState(() {
      isTyping = true;
    });

    // Generate and display AI's response on the left
    final content = [Content.text(message)];
    final response = await model.generateContent(content);

    // Hide typing indicator
    setState(() {
      isTyping = false;
      prompt.add(ModelMessage(
        isPrompt: false,  // AI response
        message: response.text ?? "",
        time: DateTime.now(),
      ));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true
        ,
        elevation: 3,
        title: const Text("AI ChatBot"),
        backgroundColor: Colors.lightBlue,
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: prompt.length + (isTyping ? 1 : 0),
              itemBuilder: (context, index) {
                if (index == prompt.length && isTyping) {
                  return const Padding(
                    padding: EdgeInsets.all(15.0),
                    child: Row(
                      children: [
                        CircularProgressIndicator(),
                        SizedBox(width: 10),
                        Text("AI is typing..."),
                      ],
                    ),
                  );
                }

                final message = prompt[index];
                return Align(
                  alignment: message.isPrompt ? Alignment.centerRight : Alignment.centerLeft,
                  child: GestureDetector(
                    onLongPress: () => deleteMessage(index),
                    child: messageBubble(
                      isPrompt: message.isPrompt,
                      message: message.message,
                      date: DateFormat('hh:mm a').format(message.time),
                    ),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(25),
            child: Row(
              children: [
                Expanded(
                  flex: 24,
                  child: TextField(
                    controller: messageController,
                    decoration: InputDecoration(
                      hintText: "Enter your message here....",
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                    ),
                  ),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: () {
                    sendMessage();
                  },
                  child: const CircleAvatar(
                    radius: 25,
                    backgroundColor: Colors.green,
                    child: Icon(
                      Icons.send_rounded,
                      color: Colors.black,
                      size: 24,
                    ),
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }

  void deleteMessage(int index) {
    setState(() {
      prompt.removeAt(index);
    });
  }

  Widget messageBubble(
      {required final bool isPrompt, required String message, required String date}) {
    return Container(
      padding: const EdgeInsets.all(15),
      margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 15),
      decoration: BoxDecoration(
        color: isPrompt ? Colors.green : Colors.grey[300],
        borderRadius: BorderRadius.only(
          topLeft: const Radius.circular(12),
          topRight: const Radius.circular(12),
          bottomLeft: isPrompt ? const Radius.circular(12) : Radius.zero,
          bottomRight: isPrompt ? Radius.zero : const Radius.circular(12),
        ),
      ),
      child: Column(
        crossAxisAlignment:
            isPrompt ? CrossAxisAlignment.end : CrossAxisAlignment.start,
        children: [
          // Display the message
          Text(
            message,
            style: TextStyle(
                fontWeight: FontWeight.normal,
                fontSize: 16,
                color: isPrompt ? Colors.white : Colors.black),
          ),
          // Display the time
          Text(
            date,
            style: TextStyle(
                fontWeight: FontWeight.normal,
                fontSize: 12,
                color: isPrompt ? Colors.white70 : Colors.black54),
          ),
        ],
      ),
    );
  }
}
